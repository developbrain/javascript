[js src="solution.view/extended-clock.js"]
