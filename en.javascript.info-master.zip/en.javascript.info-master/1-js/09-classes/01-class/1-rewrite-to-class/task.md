importance: 5

---

# Rewrite to class

The `Clock` class (see the sandbox) is written in functional style. Rewrite it in the "class" syntax.

P.S. The clock ticks in the console, open it to see.
