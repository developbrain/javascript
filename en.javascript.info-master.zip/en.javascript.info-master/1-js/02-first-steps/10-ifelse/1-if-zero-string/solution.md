**Yes, it will.**

Any string except an empty one (and `"0"` is not empty) becomes `true` in the logical context.

We can run and check:

```js run
if ("0") {
  alert( 'Hello' );
}
```

