importance: 3

---

# Check the range between

Write an `if` condition to check that `age` is between `14` and `90` inclusively.

"Inclusively" means that `age` can reach the edges `14` or `90`.
