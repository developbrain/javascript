importance: 5

---

# The result of OR AND OR

What will the result be?

```js
alert( null || 2 && 3 || 4 );
```

