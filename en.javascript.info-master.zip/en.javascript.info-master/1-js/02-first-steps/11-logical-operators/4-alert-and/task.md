importance: 3

---

# What is the result of AND'ed alerts?

What will this code show?

```js
alert( alert(1) && alert(2) );
```

