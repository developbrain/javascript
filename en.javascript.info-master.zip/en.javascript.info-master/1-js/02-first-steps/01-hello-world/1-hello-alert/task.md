importance: 5

---

# Show an alert

Create a page that shows a message "I'm JavaScript!".

Do it in a sandbox, or on your hard drive, doesn't matter, just ensure that it works.

[demo src="solution"]

