

```js run demo
for (let i = 2; i <= 10; i++) {
  if (i % 2 == 0) {
    alert( i );
  }
}
```

We use the "modulo" operator `%` to get the remainder and check for the evenness here.
