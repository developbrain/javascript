importance: 5

---

# Output a single-linked list in the reverse order

Output a single-linked list from the previous task <info:task/output-single-linked-list> in the reverse order.

Make two solutions: using a loop and using a recursion.
