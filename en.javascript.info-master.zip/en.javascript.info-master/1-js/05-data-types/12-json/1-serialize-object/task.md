importance: 5

---

# Turn the object into JSON and back

Turn the `user` into JSON and then read it back into another variable.

```js
let user = {
  name: "John Smith",
  age: 35
};
```
