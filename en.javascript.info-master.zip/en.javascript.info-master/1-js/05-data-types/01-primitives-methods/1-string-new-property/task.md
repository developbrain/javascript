importance: 5

---

# Can I add a string property?


Consider the following code:

```js
let str = "Hello";

str.test = 5;

alert(str.test);
```

How do you think, will it work? What will be shown?
