importance: 5

---

# Sum numbers from the visitor

Create a script that prompts the visitor to enter two numbers and then shows their sum.

[demo]

P.S. There is a gotcha with types.
