function count(obj) { 
  return Object.keys(obj).length;
}

