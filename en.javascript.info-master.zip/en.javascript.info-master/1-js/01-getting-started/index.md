# An introduction

About the JavaScript language and the environment to develop with it.
